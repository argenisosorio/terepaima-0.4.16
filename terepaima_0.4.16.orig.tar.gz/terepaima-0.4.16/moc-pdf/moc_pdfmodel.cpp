/****************************************************************************
** Meta object code from reading C++ file 'pdfmodel.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../sources/pdfmodel.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'pdfmodel.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_qpdfview__Model__PdfAnnotation[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_qpdfview__Model__PdfAnnotation[] = {
    "qpdfview::Model::PdfAnnotation\0"
};

void qpdfview::Model::PdfAnnotation::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData qpdfview::Model::PdfAnnotation::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject qpdfview::Model::PdfAnnotation::staticMetaObject = {
    { &Annotation::staticMetaObject, qt_meta_stringdata_qpdfview__Model__PdfAnnotation,
      qt_meta_data_qpdfview__Model__PdfAnnotation, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &qpdfview::Model::PdfAnnotation::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *qpdfview::Model::PdfAnnotation::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *qpdfview::Model::PdfAnnotation::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_qpdfview__Model__PdfAnnotation))
        return static_cast<void*>(const_cast< PdfAnnotation*>(this));
    return Annotation::qt_metacast(_clname);
}

int qpdfview::Model::PdfAnnotation::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = Annotation::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_qpdfview__Model__PdfFormField[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_qpdfview__Model__PdfFormField[] = {
    "qpdfview::Model::PdfFormField\0"
};

void qpdfview::Model::PdfFormField::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData qpdfview::Model::PdfFormField::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject qpdfview::Model::PdfFormField::staticMetaObject = {
    { &FormField::staticMetaObject, qt_meta_stringdata_qpdfview__Model__PdfFormField,
      qt_meta_data_qpdfview__Model__PdfFormField, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &qpdfview::Model::PdfFormField::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *qpdfview::Model::PdfFormField::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *qpdfview::Model::PdfFormField::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_qpdfview__Model__PdfFormField))
        return static_cast<void*>(const_cast< PdfFormField*>(this));
    return FormField::qt_metacast(_clname);
}

int qpdfview::Model::PdfFormField::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = FormField::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_qpdfview__PdfSettingsWidget[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_qpdfview__PdfSettingsWidget[] = {
    "qpdfview::PdfSettingsWidget\0"
};

void qpdfview::PdfSettingsWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData qpdfview::PdfSettingsWidget::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject qpdfview::PdfSettingsWidget::staticMetaObject = {
    { &SettingsWidget::staticMetaObject, qt_meta_stringdata_qpdfview__PdfSettingsWidget,
      qt_meta_data_qpdfview__PdfSettingsWidget, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &qpdfview::PdfSettingsWidget::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *qpdfview::PdfSettingsWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *qpdfview::PdfSettingsWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_qpdfview__PdfSettingsWidget))
        return static_cast<void*>(const_cast< PdfSettingsWidget*>(this));
    return SettingsWidget::qt_metacast(_clname);
}

int qpdfview::PdfSettingsWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = SettingsWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_qpdfview__PdfPlugin[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_qpdfview__PdfPlugin[] = {
    "qpdfview::PdfPlugin\0"
};

void qpdfview::PdfPlugin::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData qpdfview::PdfPlugin::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject qpdfview::PdfPlugin::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_qpdfview__PdfPlugin,
      qt_meta_data_qpdfview__PdfPlugin, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &qpdfview::PdfPlugin::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *qpdfview::PdfPlugin::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *qpdfview::PdfPlugin::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_qpdfview__PdfPlugin))
        return static_cast<void*>(const_cast< PdfPlugin*>(this));
    if (!strcmp(_clname, "Plugin"))
        return static_cast< Plugin*>(const_cast< PdfPlugin*>(this));
    if (!strcmp(_clname, "local.qpdfview.Plugin"))
        return static_cast< qpdfview::Plugin*>(const_cast< PdfPlugin*>(this));
    return QObject::qt_metacast(_clname);
}

int qpdfview::PdfPlugin::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
QT_END_MOC_NAMESPACE
