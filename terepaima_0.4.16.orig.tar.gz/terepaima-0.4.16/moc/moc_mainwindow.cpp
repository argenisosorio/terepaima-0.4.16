/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../sources/mainwindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_qpdfview__MainWindow[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
     134,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      22,   21,   21,   21, 0x0a,
      64,   34,   29,   21, 0x0a,
     118,   94,   29,   21, 0x2a,
     157,  143,   29,   21, 0x2a,
     184,  175,   29,   21, 0x2a,
     198,   34,   29,   21, 0x0a,
     236,   94,   29,   21, 0x2a,
     269,  143,   29,   21, 0x2a,
     295,  175,   29,   21, 0x2a,
     365,  317,   29,   21, 0x0a,
     462,  420,   29,   21, 0x2a,
     544,  512,   29,   21, 0x2a,
     587,  143,   29,   21, 0x2a,
     625,  175,   29,   21, 0x2a,
     664,  659,   21,   21, 0x0a,
     691,  685,   21,   21, 0x09,
     724,  685,   21,   21, 0x09,
     776,  760,   21,   21, 0x09,
     825,   21,   21,   21, 0x09,
     857,   21,   21,   21, 0x09,
     904,  890,   21,   21, 0x09,
     955,  943,   21,   21, 0x09,
    1010,  993,   21,   21, 0x09,
    1065, 1050,   21,   21, 0x09,
    1118, 1107,   21,   21, 0x09,
    1178, 1162,   21,   21, 0x09,
    1231, 1221,   21,   21, 0x09,
    1285, 1273,   21,   21, 0x09,
    1334, 1325,   21,   21, 0x09,
    1379, 1374,   21,   21, 0x09,
    1431, 1410,   21,   21, 0x09,
    1487, 1475,   21,   21, 0x09,
    1556, 1543,   21,   21, 0x09,
    1615, 1596,   21,   21, 0x09,
    1673, 1661,   21,   21, 0x09,
    1728, 1712,   21,   21, 0x09,
    1795, 1782,   21,   21, 0x09,
    1850, 1835,   21,   21, 0x09,
    1902,   21,   21,   21, 0x09,
    1942, 1933,   21,   21, 0x09,
    1987, 1983,   21,   21, 0x09,
    2036,   21,   21,   21, 0x09,
    2069,   21,   21,   21, 0x09,
    2100,  685,   21,   21, 0x09,
    2130,   21,   21,   21, 0x09,
    2163,   21,   21,   21, 0x09,
    2194,   21,   21,   21, 0x09,
    2214,   21,   21,   21, 0x09,
    2242,   21,   21,   21, 0x09,
    2274,   21,   21,   21, 0x09,
    2310,   21,   21,   21, 0x09,
    2333,   21,   21,   21, 0x09,
    2357,   21,   21,   21, 0x09,
    2379,   21,   21,   21, 0x09,
    2400,  175,   21,   21, 0x09,
    2439,   21,   21,   21, 0x09,
    2467,   21,   21,   21, 0x09,
    2491,   21,   21,   21, 0x09,
    2516,   21,   21,   21, 0x09,
    2540,   21,   21,   21, 0x09,
    2568,   21,   21,   21, 0x09,
    2594,   21,   21,   21, 0x09,
    2622,   21,   21,   21, 0x09,
    2649,   21,   21,   21, 0x09,
    2671,   21,   21,   21, 0x09,
    2699,   21,   21,   21, 0x09,
    2723,   21,   21,   21, 0x09,
    2759, 2751,   21,   21, 0x09,
    2798, 2751,   21,   21, 0x09,
    2835,   21,   21,   21, 0x09,
    2859, 2751,   21,   21, 0x09,
    2893, 2751,   21,   21, 0x09,
    2925, 2751,   21,   21, 0x09,
    2970, 2751,   21,   21, 0x09,
    3007, 2751,   21,   21, 0x09,
    3042,   21,   21,   21, 0x09,
    3064,   21,   21,   21, 0x09,
    3087,   21,   21,   21, 0x09,
    3115, 2751,   21,   21, 0x09,
    3153, 2751,   21,   21, 0x09,
    3190,   21,   21,   21, 0x09,
    3216,   21,   21,   21, 0x09,
    3243, 2751,   21,   21, 0x09,
    3275, 2751,   21,   21, 0x09,
    3313, 2751,   21,   21, 0x09,
    3344, 2751,   21,   21, 0x09,
    3384, 2751,   21,   21, 0x09,
    3425,   21,   21,   21, 0x09,
    3446, 2751,   21,   21, 0x09,
    3476,   21,   21,   21, 0x09,
    3504,   21,   21,   21, 0x09,
    3531,   21,   21,   21, 0x09,
    3554,   21,   21,   21, 0x09,
    3578,   21,   21,   21, 0x09,
    3606,   21,   21,   21, 0x09,
    3647,   21,   21,   21, 0x09,
    3701, 3691,   21,   21, 0x09,
    3748,   21,   21,   21, 0x09,
    3773,   21,   21,   21, 0x09,
    3800,   21,   21,   21, 0x09,
    3832,   21,   21,   21, 0x09,
    3860,   21,   21,   21, 0x09,
    3887,   21,   21,   21, 0x09,
    3917,   21,   21,   21, 0x09,
    3951,   21,   21,   21, 0x09,
    3999, 3982,   21,   21, 0x09,
    4034, 3982,   21,   21, 0x09,
    4099, 4077,   21,   21, 0x09,
    4144, 3982,   21,   21, 0x09,
    4189,   21,   21,   21, 0x09,
    4213,   21,   21,   21, 0x09,
    4234,   21,   21,   21, 0x09,
    4266,   21,   21,   21, 0x09,
    4298, 2751,   21,   21, 0x09,
    4332, 2751,   21,   21, 0x09,
    4379, 4365,   21,   21, 0x09,
    4412, 2751,   21,   21, 0x09,
    4447, 4442,   21,   21, 0x09,
    4495,   21,   21,   21, 0x09,
    4528,  685,   21,   21, 0x09,
    4560,   21,   21,   21, 0x09,
    4596,   21,   21,   21, 0x09,
    4642, 4442,   21,   21, 0x09,
    4702, 4696,   21,   21, 0x09,
    4752,   21,   21,   21, 0x09,
    4787,  685,   21,   21, 0x09,
    4821, 1983,   21,   21, 0x09,
    4863,   21,   21,   21, 0x09,
    4903, 4895,   21,   21, 0x09,
    4937,  685,   21,   21, 0x09,
    4968,   21,   21,   21, 0x09,
    4994,   21,   21,   21, 0x09,
    5036,   21, 5016,   21, 0x09,
    5055,   21, 5016,   21, 0x09,

       0        // eod
};

static const char qt_meta_stringdata_qpdfview__MainWindow[] = {
    "qpdfview::MainWindow\0\0show()\0bool\0"
    "filePath,page,highlight,quiet\0"
    "open(QString,int,QRectF,bool)\0"
    "filePath,page,highlight\0"
    "open(QString,int,QRectF)\0filePath,page\0"
    "open(QString,int)\0filePath\0open(QString)\0"
    "openInNewTab(QString,int,QRectF,bool)\0"
    "openInNewTab(QString,int,QRectF)\0"
    "openInNewTab(QString,int)\0"
    "openInNewTab(QString)\0"
    "filePath,page,refreshBeforeJump,highlight,quiet\0"
    "jumpToPageOrOpenInNewTab(QString,int,bool,QRectF,bool)\0"
    "filePath,page,refreshBeforeJump,highlight\0"
    "jumpToPageOrOpenInNewTab(QString,int,bool,QRectF)\0"
    "filePath,page,refreshBeforeJump\0"
    "jumpToPageOrOpenInNewTab(QString,int,bool)\0"
    "jumpToPageOrOpenInNewTab(QString,int)\0"
    "jumpToPageOrOpenInNewTab(QString)\0"
    "text\0startSearch(QString)\0index\0"
    "on_tabWidget_currentChanged(int)\0"
    "on_tabWidget_tabCloseRequested(int)\0"
    "globalPos,index\0"
    "on_tabWidget_tabContextMenuRequested(QPoint,int)\0"
    "on_currentTab_documentChanged()\0"
    "on_currentTab_documentModified()\0"
    "numberOfPages\0on_currentTab_numberOfPagesChaned(int)\0"
    "currentPage\0on_currentTab_currentPageChanged(int)\0"
    "backward,forward\0"
    "on_currentTab_canJumpChanged(bool,bool)\0"
    "continuousMode\0on_currentTab_continuousModeChanged(bool)\0"
    "layoutMode\0on_currentTab_layoutModeChanged(LayoutMode)\0"
    "rightToLeftMode\0"
    "on_currentTab_rightToLeftModeChanged(bool)\0"
    "scaleMode\0on_currentTab_scaleModeChanged(ScaleMode)\0"
    "scaleFactor\0on_currentTab_scaleFactorChanged(qreal)\0"
    "rotation\0on_currentTab_rotationChanged(Rotation)\0"
    "page\0on_currentTab_linkClicked(int)\0"
    "newTab,filePath,page\0"
    "on_currentTab_linkClicked(bool,QString,int)\0"
    "renderFlags\0"
    "on_currentTab_renderFlagsChanged(qpdfview::RenderFlags)\0"
    "invertColors\0on_currentTab_invertColorsChanged(bool)\0"
    "convertToGrayscale\0"
    "on_currentTab_convertToGrayscaleChanged(bool)\0"
    "trimMargins\0on_currentTab_trimMarginsChanged(bool)\0"
    "compositionMode\0"
    "on_currentTab_compositionModeChanged(CompositionMode)\0"
    "highlightAll\0on_currentTab_highlightAllChanged(bool)\0"
    "rubberBandMode\0"
    "on_currentTab_rubberBandModeChanged(RubberBandMode)\0"
    "on_currentTab_searchFinished()\0progress\0"
    "on_currentTab_searchProgressChanged(int)\0"
    "pos\0on_currentTab_customContextMenuRequested(QPoint)\0"
    "on_currentPage_editingFinished()\0"
    "on_currentPage_returnPressed()\0"
    "on_scaleFactor_activated(int)\0"
    "on_scaleFactor_editingFinished()\0"
    "on_scaleFactor_returnPressed()\0"
    "on_open_triggered()\0on_openInNewTab_triggered()\0"
    "on_openCopyInNewTab_triggered()\0"
    "on_openContainingFolder_triggered()\0"
    "on_refresh_triggered()\0on_saveCopy_triggered()\0"
    "on_saveAs_triggered()\0on_print_triggered()\0"
    "on_recentlyUsed_openTriggered(QString)\0"
    "on_previousPage_triggered()\0"
    "on_nextPage_triggered()\0"
    "on_firstPage_triggered()\0"
    "on_lastPage_triggered()\0"
    "on_setFirstPage_triggered()\0"
    "on_jumpToPage_triggered()\0"
    "on_jumpBackward_triggered()\0"
    "on_jumpForward_triggered()\0"
    "on_search_triggered()\0on_findPrevious_triggered()\0"
    "on_findNext_triggered()\0"
    "on_cancelSearch_triggered()\0checked\0"
    "on_copyToClipboardMode_triggered(bool)\0"
    "on_addAnnotationMode_triggered(bool)\0"
    "on_settings_triggered()\0"
    "on_continuousMode_triggered(bool)\0"
    "on_twoPagesMode_triggered(bool)\0"
    "on_twoPagesWithCoverPageMode_triggered(bool)\0"
    "on_multiplePagesMode_triggered(bool)\0"
    "on_rightToLeftMode_triggered(bool)\0"
    "on_zoomIn_triggered()\0on_zoomOut_triggered()\0"
    "on_originalSize_triggered()\0"
    "on_fitToPageWidthMode_triggered(bool)\0"
    "on_fitToPageSizeMode_triggered(bool)\0"
    "on_rotateLeft_triggered()\0"
    "on_rotateRight_triggered()\0"
    "on_invertColors_triggered(bool)\0"
    "on_convertToGrayscale_triggered(bool)\0"
    "on_trimMargins_triggered(bool)\0"
    "on_darkenWithPaperColor_triggered(bool)\0"
    "on_lightenWithPaperColor_triggered(bool)\0"
    "on_fonts_triggered()\0on_fullscreen_triggered(bool)\0"
    "on_presentation_triggered()\0"
    "on_previousTab_triggered()\0"
    "on_nextTab_triggered()\0on_closeTab_triggered()\0"
    "on_closeAllTabs_triggered()\0"
    "on_closeAllTabsButCurrentTab_triggered()\0"
    "on_restoreMostRecentlyClosedTab_triggered()\0"
    "tabAction\0on_recentlyClosed_tabActionTriggered(QAction*)\0"
    "on_tabAction_triggered()\0"
    "on_tabShortcut_activated()\0"
    "on_previousBookmark_triggered()\0"
    "on_nextBookmark_triggered()\0"
    "on_addBookmark_triggered()\0"
    "on_removeBookmark_triggered()\0"
    "on_removeAllBookmarks_triggered()\0"
    "on_bookmarksMenu_aboutToShow()\0"
    "absoluteFilePath\0on_bookmark_openTriggered(QString)\0"
    "on_bookmark_openInNewTabTriggered(QString)\0"
    "absoluteFilePath,page\0"
    "on_bookmark_jumpToPageTriggered(QString,int)\0"
    "on_bookmark_removeBookmarkTriggered(QString)\0"
    "on_contents_triggered()\0on_about_triggered()\0"
    "on_focusCurrentPage_activated()\0"
    "on_focusScaleFactor_activated()\0"
    "on_toggleToolBars_triggered(bool)\0"
    "on_toggleMenuBar_triggered(bool)\0"
    "text,modified\0on_searchInitiated(QString,bool)\0"
    "on_highlightAll_clicked(bool)\0area\0"
    "on_dock_dockLocationChanged(Qt::DockWidgetArea)\0"
    "on_outline_sectionCountChanged()\0"
    "on_outline_clicked(QModelIndex)\0"
    "on_properties_sectionCountChanged()\0"
    "on_detailsSignatureView_sectionCountChanged()\0"
    "on_thumbnails_dockLocationChanged(Qt::DockWidgetArea)\0"
    "value\0on_thumbnails_verticalScrollBar_valueChanged(int)\0"
    "on_bookmarks_sectionCountChanged()\0"
    "on_bookmarks_clicked(QModelIndex)\0"
    "on_bookmarks_contextMenuRequested(QPoint)\0"
    "on_search_sectionCountChanged()\0visible\0"
    "on_search_visibilityChanged(bool)\0"
    "on_search_clicked(QModelIndex)\0"
    "on_saveDatabase_timeout()\0"
    "on_verify_signature()\0QStandardItemModel*\0"
    "verify_signature()\0view_table_verify_signature()\0"
};

void qpdfview::MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MainWindow *_t = static_cast<MainWindow *>(_o);
        switch (_id) {
        case 0: _t->show(); break;
        case 1: { bool _r = _t->open((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< const QRectF(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 2: { bool _r = _t->open((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< const QRectF(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 3: { bool _r = _t->open((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 4: { bool _r = _t->open((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 5: { bool _r = _t->openInNewTab((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< const QRectF(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 6: { bool _r = _t->openInNewTab((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< const QRectF(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 7: { bool _r = _t->openInNewTab((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 8: { bool _r = _t->openInNewTab((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 9: { bool _r = _t->jumpToPageOrOpenInNewTab((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< const QRectF(*)>(_a[4])),(*reinterpret_cast< bool(*)>(_a[5])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 10: { bool _r = _t->jumpToPageOrOpenInNewTab((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< const QRectF(*)>(_a[4])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 11: { bool _r = _t->jumpToPageOrOpenInNewTab((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 12: { bool _r = _t->jumpToPageOrOpenInNewTab((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 13: { bool _r = _t->jumpToPageOrOpenInNewTab((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 14: _t->startSearch((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 15: _t->on_tabWidget_currentChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->on_tabWidget_tabCloseRequested((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: _t->on_tabWidget_tabContextMenuRequested((*reinterpret_cast< const QPoint(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 18: _t->on_currentTab_documentChanged(); break;
        case 19: _t->on_currentTab_documentModified(); break;
        case 20: _t->on_currentTab_numberOfPagesChaned((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 21: _t->on_currentTab_currentPageChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 22: _t->on_currentTab_canJumpChanged((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 23: _t->on_currentTab_continuousModeChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 24: _t->on_currentTab_layoutModeChanged((*reinterpret_cast< LayoutMode(*)>(_a[1]))); break;
        case 25: _t->on_currentTab_rightToLeftModeChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 26: _t->on_currentTab_scaleModeChanged((*reinterpret_cast< ScaleMode(*)>(_a[1]))); break;
        case 27: _t->on_currentTab_scaleFactorChanged((*reinterpret_cast< qreal(*)>(_a[1]))); break;
        case 28: _t->on_currentTab_rotationChanged((*reinterpret_cast< Rotation(*)>(_a[1]))); break;
        case 29: _t->on_currentTab_linkClicked((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 30: _t->on_currentTab_linkClicked((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 31: _t->on_currentTab_renderFlagsChanged((*reinterpret_cast< qpdfview::RenderFlags(*)>(_a[1]))); break;
        case 32: _t->on_currentTab_invertColorsChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 33: _t->on_currentTab_convertToGrayscaleChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 34: _t->on_currentTab_trimMarginsChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 35: _t->on_currentTab_compositionModeChanged((*reinterpret_cast< CompositionMode(*)>(_a[1]))); break;
        case 36: _t->on_currentTab_highlightAllChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 37: _t->on_currentTab_rubberBandModeChanged((*reinterpret_cast< RubberBandMode(*)>(_a[1]))); break;
        case 38: _t->on_currentTab_searchFinished(); break;
        case 39: _t->on_currentTab_searchProgressChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 40: _t->on_currentTab_customContextMenuRequested((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 41: _t->on_currentPage_editingFinished(); break;
        case 42: _t->on_currentPage_returnPressed(); break;
        case 43: _t->on_scaleFactor_activated((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 44: _t->on_scaleFactor_editingFinished(); break;
        case 45: _t->on_scaleFactor_returnPressed(); break;
        case 46: _t->on_open_triggered(); break;
        case 47: _t->on_openInNewTab_triggered(); break;
        case 48: _t->on_openCopyInNewTab_triggered(); break;
        case 49: _t->on_openContainingFolder_triggered(); break;
        case 50: _t->on_refresh_triggered(); break;
        case 51: _t->on_saveCopy_triggered(); break;
        case 52: _t->on_saveAs_triggered(); break;
        case 53: _t->on_print_triggered(); break;
        case 54: _t->on_recentlyUsed_openTriggered((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 55: _t->on_previousPage_triggered(); break;
        case 56: _t->on_nextPage_triggered(); break;
        case 57: _t->on_firstPage_triggered(); break;
        case 58: _t->on_lastPage_triggered(); break;
        case 59: _t->on_setFirstPage_triggered(); break;
        case 60: _t->on_jumpToPage_triggered(); break;
        case 61: _t->on_jumpBackward_triggered(); break;
        case 62: _t->on_jumpForward_triggered(); break;
        case 63: _t->on_search_triggered(); break;
        case 64: _t->on_findPrevious_triggered(); break;
        case 65: _t->on_findNext_triggered(); break;
        case 66: _t->on_cancelSearch_triggered(); break;
        case 67: _t->on_copyToClipboardMode_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 68: _t->on_addAnnotationMode_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 69: _t->on_settings_triggered(); break;
        case 70: _t->on_continuousMode_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 71: _t->on_twoPagesMode_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 72: _t->on_twoPagesWithCoverPageMode_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 73: _t->on_multiplePagesMode_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 74: _t->on_rightToLeftMode_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 75: _t->on_zoomIn_triggered(); break;
        case 76: _t->on_zoomOut_triggered(); break;
        case 77: _t->on_originalSize_triggered(); break;
        case 78: _t->on_fitToPageWidthMode_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 79: _t->on_fitToPageSizeMode_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 80: _t->on_rotateLeft_triggered(); break;
        case 81: _t->on_rotateRight_triggered(); break;
        case 82: _t->on_invertColors_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 83: _t->on_convertToGrayscale_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 84: _t->on_trimMargins_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 85: _t->on_darkenWithPaperColor_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 86: _t->on_lightenWithPaperColor_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 87: _t->on_fonts_triggered(); break;
        case 88: _t->on_fullscreen_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 89: _t->on_presentation_triggered(); break;
        case 90: _t->on_previousTab_triggered(); break;
        case 91: _t->on_nextTab_triggered(); break;
        case 92: _t->on_closeTab_triggered(); break;
        case 93: _t->on_closeAllTabs_triggered(); break;
        case 94: _t->on_closeAllTabsButCurrentTab_triggered(); break;
        case 95: _t->on_restoreMostRecentlyClosedTab_triggered(); break;
        case 96: _t->on_recentlyClosed_tabActionTriggered((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        case 97: _t->on_tabAction_triggered(); break;
        case 98: _t->on_tabShortcut_activated(); break;
        case 99: _t->on_previousBookmark_triggered(); break;
        case 100: _t->on_nextBookmark_triggered(); break;
        case 101: _t->on_addBookmark_triggered(); break;
        case 102: _t->on_removeBookmark_triggered(); break;
        case 103: _t->on_removeAllBookmarks_triggered(); break;
        case 104: _t->on_bookmarksMenu_aboutToShow(); break;
        case 105: _t->on_bookmark_openTriggered((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 106: _t->on_bookmark_openInNewTabTriggered((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 107: _t->on_bookmark_jumpToPageTriggered((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 108: _t->on_bookmark_removeBookmarkTriggered((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 109: _t->on_contents_triggered(); break;
        case 110: _t->on_about_triggered(); break;
        case 111: _t->on_focusCurrentPage_activated(); break;
        case 112: _t->on_focusScaleFactor_activated(); break;
        case 113: _t->on_toggleToolBars_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 114: _t->on_toggleMenuBar_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 115: _t->on_searchInitiated((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 116: _t->on_highlightAll_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 117: _t->on_dock_dockLocationChanged((*reinterpret_cast< Qt::DockWidgetArea(*)>(_a[1]))); break;
        case 118: _t->on_outline_sectionCountChanged(); break;
        case 119: _t->on_outline_clicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 120: _t->on_properties_sectionCountChanged(); break;
        case 121: _t->on_detailsSignatureView_sectionCountChanged(); break;
        case 122: _t->on_thumbnails_dockLocationChanged((*reinterpret_cast< Qt::DockWidgetArea(*)>(_a[1]))); break;
        case 123: _t->on_thumbnails_verticalScrollBar_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 124: _t->on_bookmarks_sectionCountChanged(); break;
        case 125: _t->on_bookmarks_clicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 126: _t->on_bookmarks_contextMenuRequested((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 127: _t->on_search_sectionCountChanged(); break;
        case 128: _t->on_search_visibilityChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 129: _t->on_search_clicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 130: _t->on_saveDatabase_timeout(); break;
        case 131: _t->on_verify_signature(); break;
        case 132: { QStandardItemModel* _r = _t->verify_signature();
            if (_a[0]) *reinterpret_cast< QStandardItemModel**>(_a[0]) = _r; }  break;
        case 133: { QStandardItemModel* _r = _t->view_table_verify_signature();
            if (_a[0]) *reinterpret_cast< QStandardItemModel**>(_a[0]) = _r; }  break;
        default: ;
        }
    }
}

const QMetaObjectExtraData qpdfview::MainWindow::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject qpdfview::MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_qpdfview__MainWindow,
      qt_meta_data_qpdfview__MainWindow, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &qpdfview::MainWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *qpdfview::MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *qpdfview::MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_qpdfview__MainWindow))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int qpdfview::MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 134)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 134;
    }
    return _id;
}
static const uint qt_meta_data_qpdfview__MainWindowAdaptor[] = {

 // content:
       6,       // revision
       0,       // classname
       1,   14, // classinfo
      36,   16, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // classinfo: key, value
      54,   28,

 // slots: signature, parameters, type, tag, flags
      81,   80,   80,   70, 0x0a,
     143,  105,  100,   80, 0x0a,
     205,  173,  100,   80, 0x2a,
     252,  230,  100,   80, 0x2a,
     287,  270,  100,   80, 0x2a,
     301,  105,  100,   80, 0x0a,
     339,  173,  100,   80, 0x2a,
     372,  230,  100,   80, 0x2a,
     398,  270,  100,   80, 0x2a,
     476,  420,  100,   80, 0x0a,
     581,  531,  100,   80, 0x2a,
     671,  631,  100,   80, 0x2a,
     714,  230,  100,   80, 0x2a,
     752,  270,  100,   80, 0x2a,
     791,  786,   80,   70, 0x0a,
     812,   80,   80,   70, 0x0a,
     827,   80,   80,   70, 0x0a,
     838,   80,   80,   70, 0x0a,
     850,   80,   80,   70, 0x0a,
     861,   80,   80,   70, 0x0a,
     880,   80,   80,   70, 0x0a,
     901,  895,  100,   80, 0x0a,
     933,  925,   80,   70, 0x0a,
     960,  925,   80,   70, 0x0a,
     985,  925,   80,   70, 0x0a,
    1023,  925,   80,   70, 0x0a,
    1053,  925,   80,   70, 0x0a,
    1084,  925,   80,   70, 0x0a,
    1114,  925,   80,   70, 0x0a,
    1145,  925,   80,   70, 0x0a,
    1170,  925,   80,   70, 0x0a,
    1193,   80,   80,   70, 0x0a,
    1214,   80,   80,   70, 0x0a,
    1225,   80,   80,   70, 0x0a,
    1240,   80,   80,   70, 0x0a,
    1268,  270,  100,   80, 0x0a,

       0        // eod
};

static const char qt_meta_stringdata_qpdfview__MainWindowAdaptor[] = {
    "qpdfview::MainWindowAdaptor\0"
    "local.qpdfview.MainWindow\0D-Bus Interface\0"
    "Q_NOREPLY\0\0raiseAndActivate()\0bool\0"
    "absoluteFilePath,page,highlight,quiet\0"
    "open(QString,int,QRectF,bool)\0"
    "absoluteFilePath,page,highlight\0"
    "open(QString,int,QRectF)\0absoluteFilePath,page\0"
    "open(QString,int)\0absoluteFilePath\0"
    "open(QString)\0openInNewTab(QString,int,QRectF,bool)\0"
    "openInNewTab(QString,int,QRectF)\0"
    "openInNewTab(QString,int)\0"
    "openInNewTab(QString)\0"
    "absoluteFilePath,page,refreshBeforeJump,highlight,quiet\0"
    "jumpToPageOrOpenInNewTab(QString,int,bool,QRectF,bool)\0"
    "absoluteFilePath,page,refreshBeforeJump,highlight\0"
    "jumpToPageOrOpenInNewTab(QString,int,bool,QRectF)\0"
    "absoluteFilePath,page,refreshBeforeJump\0"
    "jumpToPageOrOpenInNewTab(QString,int,bool)\0"
    "jumpToPageOrOpenInNewTab(QString,int)\0"
    "jumpToPageOrOpenInNewTab(QString)\0"
    "text\0startSearch(QString)\0previousPage()\0"
    "nextPage()\0firstPage()\0lastPage()\0"
    "previousBookmark()\0nextBookmark()\0"
    "label\0jumpToBookmark(QString)\0checked\0"
    "continuousModeAction(bool)\0"
    "twoPagesModeAction(bool)\0"
    "twoPagesWithCoverPageModeAction(bool)\0"
    "multiplePagesModeAction(bool)\0"
    "fitToPageWidthModeAction(bool)\0"
    "fitToPageSizeModeAction(bool)\0"
    "convertToGrayscaleAction(bool)\0"
    "invertColorsAction(bool)\0"
    "fullscreenAction(bool)\0presentationAction()\0"
    "closeTab()\0closeAllTabs()\0"
    "closeAllTabsButCurrentTab()\0"
    "closeTab(QString)\0"
};

void qpdfview::MainWindowAdaptor::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        MainWindowAdaptor *_t = static_cast<MainWindowAdaptor *>(_o);
        switch (_id) {
        case 0: _t->raiseAndActivate(); break;
        case 1: { bool _r = _t->open((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< const QRectF(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 2: { bool _r = _t->open((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< const QRectF(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 3: { bool _r = _t->open((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 4: { bool _r = _t->open((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 5: { bool _r = _t->openInNewTab((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< const QRectF(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 6: { bool _r = _t->openInNewTab((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< const QRectF(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 7: { bool _r = _t->openInNewTab((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 8: { bool _r = _t->openInNewTab((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 9: { bool _r = _t->jumpToPageOrOpenInNewTab((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< const QRectF(*)>(_a[4])),(*reinterpret_cast< bool(*)>(_a[5])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 10: { bool _r = _t->jumpToPageOrOpenInNewTab((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< const QRectF(*)>(_a[4])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 11: { bool _r = _t->jumpToPageOrOpenInNewTab((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 12: { bool _r = _t->jumpToPageOrOpenInNewTab((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 13: { bool _r = _t->jumpToPageOrOpenInNewTab((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 14: _t->startSearch((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 15: _t->previousPage(); break;
        case 16: _t->nextPage(); break;
        case 17: _t->firstPage(); break;
        case 18: _t->lastPage(); break;
        case 19: _t->previousBookmark(); break;
        case 20: _t->nextBookmark(); break;
        case 21: { bool _r = _t->jumpToBookmark((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 22: _t->continuousModeAction((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 23: _t->twoPagesModeAction((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 24: _t->twoPagesWithCoverPageModeAction((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 25: _t->multiplePagesModeAction((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 26: _t->fitToPageWidthModeAction((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 27: _t->fitToPageSizeModeAction((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 28: _t->convertToGrayscaleAction((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 29: _t->invertColorsAction((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 30: _t->fullscreenAction((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 31: _t->presentationAction(); break;
        case 32: _t->closeTab(); break;
        case 33: _t->closeAllTabs(); break;
        case 34: _t->closeAllTabsButCurrentTab(); break;
        case 35: { bool _r = _t->closeTab((*reinterpret_cast< const QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        default: ;
        }
    }
}

const QMetaObjectExtraData qpdfview::MainWindowAdaptor::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject qpdfview::MainWindowAdaptor::staticMetaObject = {
    { &QDBusAbstractAdaptor::staticMetaObject, qt_meta_stringdata_qpdfview__MainWindowAdaptor,
      qt_meta_data_qpdfview__MainWindowAdaptor, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &qpdfview::MainWindowAdaptor::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *qpdfview::MainWindowAdaptor::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *qpdfview::MainWindowAdaptor::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_qpdfview__MainWindowAdaptor))
        return static_cast<void*>(const_cast< MainWindowAdaptor*>(this));
    return QDBusAbstractAdaptor::qt_metacast(_clname);
}

int qpdfview::MainWindowAdaptor::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDBusAbstractAdaptor::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 36)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 36;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
