/****************************************************************************
** Meta object code from reading C++ file 'miscellaneous.h'
**
** Created by: The Qt Meta Object Compiler version 63 (Qt 4.8.6)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../sources/miscellaneous.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'miscellaneous.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.6. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_qpdfview__GraphicsCompositionModeEffect[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_qpdfview__GraphicsCompositionModeEffect[] = {
    "qpdfview::GraphicsCompositionModeEffect\0"
};

void qpdfview::GraphicsCompositionModeEffect::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData qpdfview::GraphicsCompositionModeEffect::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject qpdfview::GraphicsCompositionModeEffect::staticMetaObject = {
    { &QGraphicsEffect::staticMetaObject, qt_meta_stringdata_qpdfview__GraphicsCompositionModeEffect,
      qt_meta_data_qpdfview__GraphicsCompositionModeEffect, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &qpdfview::GraphicsCompositionModeEffect::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *qpdfview::GraphicsCompositionModeEffect::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *qpdfview::GraphicsCompositionModeEffect::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_qpdfview__GraphicsCompositionModeEffect))
        return static_cast<void*>(const_cast< GraphicsCompositionModeEffect*>(this));
    return QGraphicsEffect::qt_metacast(_clname);
}

int qpdfview::GraphicsCompositionModeEffect::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QGraphicsEffect::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_qpdfview__ProxyStyle[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_qpdfview__ProxyStyle[] = {
    "qpdfview::ProxyStyle\0"
};

void qpdfview::ProxyStyle::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData qpdfview::ProxyStyle::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject qpdfview::ProxyStyle::staticMetaObject = {
    { &QProxyStyle::staticMetaObject, qt_meta_stringdata_qpdfview__ProxyStyle,
      qt_meta_data_qpdfview__ProxyStyle, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &qpdfview::ProxyStyle::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *qpdfview::ProxyStyle::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *qpdfview::ProxyStyle::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_qpdfview__ProxyStyle))
        return static_cast<void*>(const_cast< ProxyStyle*>(this));
    return QProxyStyle::qt_metacast(_clname);
}

int qpdfview::ProxyStyle::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QProxyStyle::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_qpdfview__SearchableMenu[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_qpdfview__SearchableMenu[] = {
    "qpdfview::SearchableMenu\0"
};

void qpdfview::SearchableMenu::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData qpdfview::SearchableMenu::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject qpdfview::SearchableMenu::staticMetaObject = {
    { &QMenu::staticMetaObject, qt_meta_stringdata_qpdfview__SearchableMenu,
      qt_meta_data_qpdfview__SearchableMenu, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &qpdfview::SearchableMenu::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *qpdfview::SearchableMenu::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *qpdfview::SearchableMenu::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_qpdfview__SearchableMenu))
        return static_cast<void*>(const_cast< SearchableMenu*>(this));
    return QMenu::qt_metacast(_clname);
}

int qpdfview::SearchableMenu::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMenu::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_qpdfview__TabBar[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_qpdfview__TabBar[] = {
    "qpdfview::TabBar\0"
};

void qpdfview::TabBar::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData qpdfview::TabBar::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject qpdfview::TabBar::staticMetaObject = {
    { &QTabBar::staticMetaObject, qt_meta_stringdata_qpdfview__TabBar,
      qt_meta_data_qpdfview__TabBar, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &qpdfview::TabBar::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *qpdfview::TabBar::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *qpdfview::TabBar::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_qpdfview__TabBar))
        return static_cast<void*>(const_cast< TabBar*>(this));
    return QTabBar::qt_metacast(_clname);
}

int qpdfview::TabBar::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QTabBar::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_qpdfview__TabWidget[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      37,   21,   20,   20, 0x05,

 // slots: signature, parameters, type, tag, flags
      77,   73,   20,   20, 0x09,

       0        // eod
};

static const char qt_meta_stringdata_qpdfview__TabWidget[] = {
    "qpdfview::TabWidget\0\0globalPos,index\0"
    "tabContextMenuRequested(QPoint,int)\0"
    "pos\0on_tabBar_customContextMenuRequested(QPoint)\0"
};

void qpdfview::TabWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        TabWidget *_t = static_cast<TabWidget *>(_o);
        switch (_id) {
        case 0: _t->tabContextMenuRequested((*reinterpret_cast< const QPoint(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 1: _t->on_tabBar_customContextMenuRequested((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData qpdfview::TabWidget::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject qpdfview::TabWidget::staticMetaObject = {
    { &QTabWidget::staticMetaObject, qt_meta_stringdata_qpdfview__TabWidget,
      qt_meta_data_qpdfview__TabWidget, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &qpdfview::TabWidget::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *qpdfview::TabWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *qpdfview::TabWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_qpdfview__TabWidget))
        return static_cast<void*>(const_cast< TabWidget*>(this));
    return QTabWidget::qt_metacast(_clname);
}

int qpdfview::TabWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QTabWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    }
    return _id;
}

// SIGNAL 0
void qpdfview::TabWidget::tabContextMenuRequested(const QPoint & _t1, int _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
static const uint qt_meta_data_qpdfview__TreeView[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      12,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      26,   20,   19,   19, 0x0a,
      57,   51,   19,   19, 0x0a,
      80,   19,   19,   19, 0x2a,
      92,   51,   19,   19, 0x0a,
     117,   19,   19,   19, 0x2a,
     135,   51,  131,   19, 0x0a,
     174,  162,   19,   19, 0x0a,
     205,  162,   19,   19, 0x0a,
     240,   51,   19,   19, 0x0a,
     270,   19,   19,   19, 0x2a,
     289,   51,   19,   19, 0x09,
     314,   51,   19,   19, 0x09,

       0        // eod
};

static const char qt_meta_stringdata_qpdfview__TreeView[] = {
    "qpdfview::TreeView\0\0child\0"
    "expandAbove(QModelIndex)\0index\0"
    "expandAll(QModelIndex)\0expandAll()\0"
    "collapseAll(QModelIndex)\0collapseAll()\0"
    "int\0expandedDepth(QModelIndex)\0"
    "index,depth\0expandToDepth(QModelIndex,int)\0"
    "collapseFromDepth(QModelIndex,int)\0"
    "restoreExpansion(QModelIndex)\0"
    "restoreExpansion()\0on_expanded(QModelIndex)\0"
    "on_collapsed(QModelIndex)\0"
};

void qpdfview::TreeView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        TreeView *_t = static_cast<TreeView *>(_o);
        switch (_id) {
        case 0: _t->expandAbove((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 1: _t->expandAll((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 2: _t->expandAll(); break;
        case 3: _t->collapseAll((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 4: _t->collapseAll(); break;
        case 5: { int _r = _t->expandedDepth((*reinterpret_cast< const QModelIndex(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 6: _t->expandToDepth((*reinterpret_cast< const QModelIndex(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 7: _t->collapseFromDepth((*reinterpret_cast< const QModelIndex(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 8: _t->restoreExpansion((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 9: _t->restoreExpansion(); break;
        case 10: _t->on_expanded((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 11: _t->on_collapsed((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData qpdfview::TreeView::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject qpdfview::TreeView::staticMetaObject = {
    { &QTreeView::staticMetaObject, qt_meta_stringdata_qpdfview__TreeView,
      qt_meta_data_qpdfview__TreeView, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &qpdfview::TreeView::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *qpdfview::TreeView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *qpdfview::TreeView::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_qpdfview__TreeView))
        return static_cast<void*>(const_cast< TreeView*>(this));
    return QTreeView::qt_metacast(_clname);
}

int qpdfview::TreeView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QTreeView::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 12)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    }
    return _id;
}
static const uint qt_meta_data_qpdfview__LineEdit[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_qpdfview__LineEdit[] = {
    "qpdfview::LineEdit\0"
};

void qpdfview::LineEdit::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData qpdfview::LineEdit::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject qpdfview::LineEdit::staticMetaObject = {
    { &QLineEdit::staticMetaObject, qt_meta_stringdata_qpdfview__LineEdit,
      qt_meta_data_qpdfview__LineEdit, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &qpdfview::LineEdit::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *qpdfview::LineEdit::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *qpdfview::LineEdit::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_qpdfview__LineEdit))
        return static_cast<void*>(const_cast< LineEdit*>(this));
    return QLineEdit::qt_metacast(_clname);
}

int qpdfview::LineEdit::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QLineEdit::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_qpdfview__ComboBox[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_qpdfview__ComboBox[] = {
    "qpdfview::ComboBox\0"
};

void qpdfview::ComboBox::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData qpdfview::ComboBox::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject qpdfview::ComboBox::staticMetaObject = {
    { &QComboBox::staticMetaObject, qt_meta_stringdata_qpdfview__ComboBox,
      qt_meta_data_qpdfview__ComboBox, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &qpdfview::ComboBox::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *qpdfview::ComboBox::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *qpdfview::ComboBox::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_qpdfview__ComboBox))
        return static_cast<void*>(const_cast< ComboBox*>(this));
    return QComboBox::qt_metacast(_clname);
}

int qpdfview::ComboBox::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QComboBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_qpdfview__SpinBox[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      19,   18,   18,   18, 0x05,

       0        // eod
};

static const char qt_meta_stringdata_qpdfview__SpinBox[] = {
    "qpdfview::SpinBox\0\0returnPressed()\0"
};

void qpdfview::SpinBox::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        SpinBox *_t = static_cast<SpinBox *>(_o);
        switch (_id) {
        case 0: _t->returnPressed(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObjectExtraData qpdfview::SpinBox::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject qpdfview::SpinBox::staticMetaObject = {
    { &QSpinBox::staticMetaObject, qt_meta_stringdata_qpdfview__SpinBox,
      qt_meta_data_qpdfview__SpinBox, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &qpdfview::SpinBox::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *qpdfview::SpinBox::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *qpdfview::SpinBox::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_qpdfview__SpinBox))
        return static_cast<void*>(const_cast< SpinBox*>(this));
    return QSpinBox::qt_metacast(_clname);
}

int qpdfview::SpinBox::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QSpinBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}

// SIGNAL 0
void qpdfview::SpinBox::returnPressed()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}
static const uint qt_meta_data_qpdfview__MappingSpinBox[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

static const char qt_meta_stringdata_qpdfview__MappingSpinBox[] = {
    "qpdfview::MappingSpinBox\0"
};

void qpdfview::MappingSpinBox::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObjectExtraData qpdfview::MappingSpinBox::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject qpdfview::MappingSpinBox::staticMetaObject = {
    { &SpinBox::staticMetaObject, qt_meta_stringdata_qpdfview__MappingSpinBox,
      qt_meta_data_qpdfview__MappingSpinBox, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &qpdfview::MappingSpinBox::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *qpdfview::MappingSpinBox::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *qpdfview::MappingSpinBox::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_qpdfview__MappingSpinBox))
        return static_cast<void*>(const_cast< MappingSpinBox*>(this));
    return SpinBox::qt_metacast(_clname);
}

int qpdfview::MappingSpinBox::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = SpinBox::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
static const uint qt_meta_data_qpdfview__ProgressLineEdit[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: signature, parameters, type, tag, flags
      38,   28,   27,   27, 0x05,

       0        // eod
};

static const char qt_meta_stringdata_qpdfview__ProgressLineEdit[] = {
    "qpdfview::ProgressLineEdit\0\0modifiers\0"
    "returnPressed(Qt::KeyboardModifiers)\0"
};

void qpdfview::ProgressLineEdit::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        ProgressLineEdit *_t = static_cast<ProgressLineEdit *>(_o);
        switch (_id) {
        case 0: _t->returnPressed((*reinterpret_cast< const Qt::KeyboardModifiers(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData qpdfview::ProgressLineEdit::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject qpdfview::ProgressLineEdit::staticMetaObject = {
    { &QLineEdit::staticMetaObject, qt_meta_stringdata_qpdfview__ProgressLineEdit,
      qt_meta_data_qpdfview__ProgressLineEdit, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &qpdfview::ProgressLineEdit::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *qpdfview::ProgressLineEdit::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *qpdfview::ProgressLineEdit::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_qpdfview__ProgressLineEdit))
        return static_cast<void*>(const_cast< ProgressLineEdit*>(this));
    return QLineEdit::qt_metacast(_clname);
}

int qpdfview::ProgressLineEdit::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QLineEdit::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}

// SIGNAL 0
void qpdfview::ProgressLineEdit::returnPressed(const Qt::KeyboardModifiers & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
static const uint qt_meta_data_qpdfview__SearchLineEdit[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: signature, parameters, type, tag, flags
      40,   26,   25,   25, 0x05,
      75,   70,   25,   25, 0x25,

 // slots: signature, parameters, type, tag, flags
     100,   25,   25,   25, 0x0a,
     114,   25,   25,   25, 0x0a,
     127,   25,   25,   25, 0x0a,
     139,   25,   25,   25, 0x09,
     162,  152,   25,   25, 0x09,

       0        // eod
};

static const char qt_meta_stringdata_qpdfview__SearchLineEdit[] = {
    "qpdfview::SearchLineEdit\0\0text,modified\0"
    "searchInitiated(QString,bool)\0text\0"
    "searchInitiated(QString)\0startSearch()\0"
    "startTimer()\0stopTimer()\0on_timeout()\0"
    "modifiers\0on_returnPressed(Qt::KeyboardModifiers)\0"
};

void qpdfview::SearchLineEdit::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        SearchLineEdit *_t = static_cast<SearchLineEdit *>(_o);
        switch (_id) {
        case 0: _t->searchInitiated((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 1: _t->searchInitiated((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: _t->startSearch(); break;
        case 3: _t->startTimer(); break;
        case 4: _t->stopTimer(); break;
        case 5: _t->on_timeout(); break;
        case 6: _t->on_returnPressed((*reinterpret_cast< const Qt::KeyboardModifiers(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData qpdfview::SearchLineEdit::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject qpdfview::SearchLineEdit::staticMetaObject = {
    { &ProgressLineEdit::staticMetaObject, qt_meta_stringdata_qpdfview__SearchLineEdit,
      qt_meta_data_qpdfview__SearchLineEdit, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &qpdfview::SearchLineEdit::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *qpdfview::SearchLineEdit::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *qpdfview::SearchLineEdit::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_qpdfview__SearchLineEdit))
        return static_cast<void*>(const_cast< SearchLineEdit*>(this));
    return ProgressLineEdit::qt_metacast(_clname);
}

int qpdfview::SearchLineEdit::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = ProgressLineEdit::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    }
    return _id;
}

// SIGNAL 0
void qpdfview::SearchLineEdit::searchInitiated(const QString & _t1, bool _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
